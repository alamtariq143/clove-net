import boto3
import pandas as pd

from awsglue.transforms import *
from awsglue.dynamicframe import DynamicFrame
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.context import SparkContext
from pyspark.sql import SparkSession
from awsglue.context import GlueContext
from awsglue.job import Job

s3 = boto3.resource('s3')
bucket_name = "cap-qa-data-lake"
my_bucket = s3.Bucket(bucket_name)
s3_client = boto3.client('s3')

sc = SparkContext()
glueContext = GlueContext(sc)
spark = SparkSession.builder.config("spark.sql.broadcastTimeout", "4000").getOrCreate()
job = Job(glueContext)

na_values = ["",
             "#N/A", 
             "#N/A N/A", 
             "#NA", 
             "-1.#IND", 
             "-1.#QNAN", 
             "-NaN", 
             "-nan", 
             "1.#IND", 
             "1.#QNAN", 
             "<NA>", 
             "N/A", 
             "NULL", 
             "NaN", 
             "n/a", 
             "nan", 
             "null"]

for obj in my_bucket.objects.filter(Prefix="pricing-app/Input_Source_data/Mapping/Excel_files/"):
        
        file_path = "s3://{}/{}".format(bucket_name, obj.key)
        print("\n \n")
        
        ## Just add the lines below to skip the first loop
        source_filename = (obj.key).split('/')[-1]
        if not source_filename:
            continue
        
        
        if "1_4_21_Historical_RMC" in file_path:
            continue
        
        if "pricing_opportunities_review" in file_path:
            continue
        
        output_dir = source_filename.replace(".xlsx", "")
        
        
        print("\n \n")
        PREFIX = "pricing-app/Input_Source_data/Mapping/Mapping_files_parquet/" + output_dir + "/"
        response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=PREFIX)
    
        if 'Contents' in response.keys():
            
            for objj in response['Contents']:
                print('Deleting', objj['Key'])
                s3_client.delete_object(Bucket=bucket_name, Key=objj['Key'])
            
        print("deleted")
        
        df = pd.read_excel(file_path, engine='openpyxl', na_values=na_values, keep_default_na = False)
        df = df.rename(str.strip, axis='columns')
        df['upload_date'] = pd.Timestamp.now()
        df['upload_date'] = df['upload_date'].astype(str)
        print("\n 1 \n")
        if source_filename == "in_1_4_14_mapping_accountmanager_input.xlsx":
            print("\n 2 \n")
            df['customer'] = df['customer'].astype(str)
            print("\n 3 \n")
            df['ml2'] = df['ml2'].astype(str)
            print("\n 4 \n")
        elif source_filename == "in_1_4_18_mapping_plant_details.xlsx":
            df['plant'] = df['plant'].astype(str)
            
        elif source_filename == "in_1_4_5_mapping_payment_terms_fee.xlsx":
            df['premium_percent'] = df['premium_percent'].astype(str)
            df['premium_percent'] = df['premium_percent'].str.replace('-','')
            print(df['premium_percent'].unique())
            df['discount'] = df['discount'].astype(str)
            df['discount'] = df['discount'].str.replace('-','')
            df['cpmt'] = df['cpmt'].astype(str)
            
        elif source_filename == "in_1_4_8_mapping_missing_product_ml2.xlsx":
            df['produced_material'] = df['produced_material'].astype(str)
            df['ml2'] = df['ml2'].astype(str)
            
        elif source_filename == "in_1_4_23_mapping_customers_to_customer_group_and_ML2.xlsx":
            df['ML2'] = df['ML2'].astype(str)
            df['ML3'] = df['ML3'].astype(str)
            df['ML4'] = df['ML4'].astype(str)
            df['customer_ship_to'] = df['customer_ship_to'].astype(str)
            
        elif source_filename == "in_1_4_25_mapping_ml2_cxp_without_sales.xlsx":
            df['ML2'] = df['ML2'].astype(str)
            df['pfam'] = df['pfam'].astype(str)
            
        elif source_filename == "in_1_4_28_mapping_ml2_cxp_without_sales_cust.xlsx":
            df['ML2'] = df['ML2'].astype(str)
            df = df.dropna(subset=['cust_number'])
            
            df['cust_number'] = df['cust_number'].astype('int64')
            df['cust_number'] = df['cust_number'].astype(str)
            
        elif source_filename == "in_1_4_27_mapping_ml2_cxp_without_sales_PH3.xlsx":
            df['ML2'] = df['ML2'].astype(str)
            df['pfam'] = df['pfam'].astype(str)
            
        elif source_filename == "in_1_4_26_mapping_weekly_file_distribution_list.xlsx":
            df['ml2'] = df['ml2'].astype(str)

        elif source_filename == "in_1_4_24_mapping_thresholds_salesorg.xlsx":
            df['sales_org_id'] = df['sales_org_id'].astype(str)
            
        elif source_filename == "in_1_4_19_Mapping_Portfolio_strategic_overwrite_opportunities.xlsx":
            df = pd.read_excel(file_path, engine='openpyxl', na_values=na_values, keep_default_na = False)
            
        elif source_filename == "in_1_4_20_Mapping_portfolio_strategic_overwrite_cxp_without_sales.xlsx":
            df = pd.read_excel(file_path, engine='openpyxl', na_values=na_values, keep_default_na = False)
            
        elif source_filename == "in_1_4_7_mapping_new_product_positioning.xlsx":
            
            df['pg_cm_stats'] = df['pg_cm_stats'].astype(str)
            df['pg_cm_stats'] = df['pg_cm_stats'].str.replace('-','')
            df['pg_cm_stats'] = df['pg_cm_stats'].str.replace(' ','')
            df['pg_cm_stats'] = pd.to_numeric(df['pg_cm_stats'])
            df['pg_cm'] = df['pg_cm'].astype(str)
            df['pg_cost'] = df['pg_cost'].astype(str)
            
        [df[col].fillna("", inplace=True) for col in df.columns if (df[col].dtype == object)]
        
        sparkDf = spark.createDataFrame(df)
        
        sparkDf = sparkDf.repartition(1)
        
        temp_df = DynamicFrame.fromDF(sparkDf, glueContext, output_dir)
        in_mapping_output = glueContext.write_dynamic_frame.from_options(frame = temp_df, connection_type = "s3", connection_options = {"path": "s3://cap-qa-data-lake/pricing-app/Input_Source_data/Mapping/Mapping_files_parquet/"+output_dir}, format = "parquet", transformation_ctx = "in_mapping_output")

job.commit()