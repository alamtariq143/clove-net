import boto3
import pandas as pd

from awsglue.transforms import *
from awsglue.dynamicframe import DynamicFrame
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.context import SparkContext
from pyspark.sql import SparkSession
from awsglue.context import GlueContext
from awsglue.job import Job
  
s3 = boto3.resource('s3')

bucket_name = "cap-qa-data-lake"
my_bucket = s3.Bucket(bucket_name)
s3_client = boto3.client('s3')

sc = SparkContext()
glueContext = GlueContext(sc)
spark = SparkSession.builder.config("spark.sql.broadcastTimeout", "4000").getOrCreate()
job = Job(glueContext)


na_values = ["",
             "#N/A", 
             "#N/A N/A", 
             "#NA", 
             "-1.#IND", 
             "-1.#QNAN", 
             "-NaN", 
             "-nan", 
             "1.#IND", 
             "1.#QNAN", 
             "<NA>", 
             "N/A", 
             "NULL", 
             "NaN", 
             "n/a", 
             "nan", 
             "null"]
             
          
PREFIX = "pricing-app/Input_Source_data/Mapping/Mapping_files_parquet/in_1_4_21_mapping_forward_looking_rmc/"

response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=PREFIX)

    
if 'Contents' in response.keys():
            
    for objj in response['Contents']:
        print('Deleting', objj['Key'])
        s3_client.delete_object(Bucket=bucket_name, Key=objj['Key'])
            
print("deleted")



output_dir = "historical_RMC"

flag = 0

for obj in my_bucket.objects.filter(Prefix="pricing-app/Input_Source_data/Mapping/Excel_files/1_4_21_Historical_RMC/"):
        
    file_path = "s3://{}/{}".format(bucket_name, obj.key)
    print("*" * 40)
    print("FILENAME \n")
    print(file_path)
    
    PREFIX = "pricing-app/Input_Source_data/Mapping/Mapping_files_parquet/1_4_21_Historical_RMC/" + output_dir + "_current_month/"

    response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=PREFIX)
    
    ## Just add the lines before to skip the first loop
    source_filename = (obj.key).split('/')[-1]
    if not source_filename:
        print("skipped")
        continue
    
    if 'Contents' in response.keys():
            
        for objj in response['Contents']:
            print('Deleting', objj['Key'])
            s3_client.delete_object(Bucket=bucket_name, Key=objj['Key'])
            
    print("deleted")
    
    df = pd.read_excel(file_path,  engine='openpyxl',  na_values=na_values, keep_default_na = False)
    
    print(df.dtypes)

    df = df.rename(columns={"Unpacked product code": "unpacked_product_code", "Unpacked product name": "unpacked_product_name", \
                            "RMC (manual) - shipto EMEA": "rmc_manual_shipto_emea", "RMC (manual) - shipto LATAM": "rmc_manual_shipto_latam", \
                            "RMC (manual) - shipto APAC": "rmc_manual_shipto_apac", "RMC (manual) - shipto NA": "rmc_manual_shipto_na", "Month+1": "month"})
        
    print("\n1\n")
    print(df.dtypes)
    df['unpacked_product_name'] = df['unpacked_product_name'].astype(str)
    df['unpacked_product_code'] = df['unpacked_product_code'].astype(str)
    df['month'] = df['month'].astype(str)
    print("\n2\n")
    print(df.dtypes)
    
    if flag == 0:
        rmcDf = spark.createDataFrame(df)
        
        rmcDf = rmcDf.withColumn("unpacked_product_name", rmcDf.unpacked_product_name.cast(StringType()))
        rmcDf = rmcDf.withColumn("unpacked_product_code", rmcDf.unpacked_product_code.cast(StringType()))
        rmcDf = rmcDf.withColumn("month", rmcDf.month.cast(StringType()))
        flag = 1
    else:
        
        temp = spark.createDataFrame(df)
        print("???")
        temp = temp.withColumn("unpacked_product_name", temp.unpacked_product_name.cast(StringType()))
        temp = temp.withColumn("unpacked_product_code", temp.unpacked_product_code.cast(StringType()))
        temp = temp.withColumn("month", temp.month.cast(StringType()))
        rmcDf = rmcDf.union(temp)
    
        print(temp.dtypes)
        temp_df = DynamicFrame.fromDF(temp, glueContext, "temp")
    

        in_mapping_output_monthly = glueContext.write_dynamic_frame.from_options(frame = temp_df, connection_type = "s3", connection_options = {"path": "s3://cap-qa-data-lake/pricing-app/Input_Source_data/Mapping/Mapping_files_parquet/"+ output_dir + "_current_month"}, format = "parquet", transformation_ctx = "in_mapping_output_current_month")



rmcDf = rmcDf.drop_duplicates()

print(rmcDf.count())

rmcDf_full = DynamicFrame.fromDF(rmcDf, glueContext, "mapping_forward_looking_rmc")

in_mapping_output = glueContext.write_dynamic_frame.from_options(frame = rmcDf_full, connection_type = "s3", connection_options = {"path": "s3://cap-qa-data-lake/pricing-app/Input_Source_data/Mapping/Mapping_files_parquet/in_1_4_21_mapping_forward_looking_rmc"}, format = "parquet", transformation_ctx = "in_mapping_output")

job.commit()
