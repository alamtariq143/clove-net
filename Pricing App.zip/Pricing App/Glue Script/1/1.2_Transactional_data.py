import boto3
import pandas as pd

from awsglue.transforms import *
from awsglue.dynamicframe import DynamicFrame
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.context import SparkContext
from pyspark.sql import SparkSession
from awsglue.context import GlueContext
from awsglue.job import Job

na_values = ["",
             "#N/A", 
             "#N/A N/A", 
             "#NA", 
             "-1.#IND", 
             "-1.#QNAN", 
             "-NaN", 
             "-nan", 
             "1.#IND", 
             "1.#QNAN", 
             "<NA>", 
             "N/A", 
             "NULL", 
             "NaN", 
             "n/a", 
             "nan", 
             "null"]
             
             
s3 = boto3.resource('s3')
bucket_name = "cap-qa-data-lake"
my_bucket = s3.Bucket(bucket_name)
s3_client = boto3.client('s3')
sc = SparkContext()
glueContext = GlueContext(sc)
spark = SparkSession.builder.config("spark.sql.broadcastTimeout", "4000").getOrCreate()
job = Job(glueContext)


        
output_dir = "bw_transaction_data"

PREFIX = "pricing-app/Input_Source_data/Transaction_data/transaction_data_parquet_files/" + output_dir + "/"

response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=PREFIX)
    
if 'Contents' in response.keys():
                
    for objj in response['Contents']:
        print('Deleting', objj['Key'])
        s3_client.delete_object(Bucket=bucket_name, Key=objj['Key'])
                
print("deleted")
    
        
print("1")

sales_org = glueContext.create_dynamic_frame.from_catalog(database = "rfm_insights", table_name= "ds_2_6_24_mapping_thresholds_salesorg", transformation_ctx = "datasource8")

sales_org = sales_org.toDF()
sales_org = sales_org.select("sales_org_id").distinct()
sales_org = sales_org.withColumn("sales_org_id",col("sales_org_id").cast(StringType()))
sales_org = sales_org.toPandas()
sales_org = sales_org['sales_org_id'].tolist()


flag = 0

for obj in my_bucket.objects.filter(Prefix="pricing-app/Input_Source_data/Transaction_data/Excel_Files/"):

    
    file_path = "s3://{}/{}".format(bucket_name, obj.key)
    print("\n " + file_path)
    source_filename = (obj.key).split('/')[-1]
    if not source_filename:
        print("skipped")
        continue
    
    PREFIX = "pricing-app/Input_Source_data/Transaction_data/transaction_data_parquet_files/" + output_dir + "_current_month/"
    
    print("2")
    
    response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=PREFIX)
    
    #print(source_filename)
    if 'Contents' in response.keys():
                
        for objj in response['Contents']:
            #print('Deleting', objj['Key'])
            s3_client.delete_object(Bucket=bucket_name, Key=objj['Key'])
                
    #print("deleted")
    
    #print(file_path)
    print("3")
    df = pd.read_excel(file_path, sheet_name='sheet 1', engine='openpyxl',  na_values=na_values, keep_default_na = False)
     
    print("4")
    df = df.rename(columns={"Sold-to party": "sold_to_party", "Sold-to party Description": "sold_to_party_description", "Material": "material", 
        "Material Description": "material_description", "Fiscal year": "fiscal_year", 
        "Posting period": "posting_period", "Region ship-to": "region_ship_to", "Reporting Unit, book": "reporting_unit_book", 
        "Reporting Unit Text": "reporting_unit_text", "Country ship-to": "country_ship_to", "Marketing Customer sold-to": "marketing_customer_sold_to", 
        "Marketing Level 2": "marketing_level_2", "ML2 ID": "ml2_id_text", "Marketing Level 4": "marketing_level_4", "ML4 ID": "ml4_id_text", 
        "Prod.Hier.2": "prod_hier_2", "Prod.Hier.2 Description": "prod_hier_2_descrp", "Prod.Hier.3": "prod_hier_3", "Prod.Hier.3 Description": "prod_hier_3_descrp", 
        "Extern. Sales Office": "extern_sales_office", "Sales Organization": "sales_org", "Sales Organization Description": "sales_org_descrp", 
        "Plant": "plant", "Plant Description": "plant_descrp", "Currency": "currency", "Unpacked good": "unpacked_good", 
        "Unpacked good Description": "unpacked_good_descrp", "Produced Material": "produced_material", "Cust.Seg.(Sold_to)": "cust_segment_sold_to", 
        "Prod.Hier.4": "prod_hier_4", "Prod.Hier.4 Description": "prod_hier_4_descrp", "Gross Sales Qty (in+ex)": "gross_sales_qty_kg", 
        "Consolidated Marginal Income I": "consolidated_marginal_income_eur", "Gross Sales": "gross_sales_eur", "Sales Deductions": "sales_deductions_eur", 
        "Net Sales": "net_sales_eur", "Commission Expenses": "commission_expenses_eur", "License Fees": "license_fees_eur", 
        "Outward Freights": "outward_freights_eur", "Transport Insurance": "transport_insurance_eur", "Other Sales Adjustm.": "other_sales_eur", 
        "Total Raw Materials / Goods for Resale": "total_raw_material_goods_resale_eur", "Total Manufact. Costs, Var.": "total_manufact_costs_var_eur", 
        "thereof replaced by COSMOS": "thereof_replaced_by_cosmos_eur", "Set-up / Clean-up": "set_up_clean_up_eur", 
        "Machine Activity": "machine_activity_eur", "Personnel Activity": "personnel_activity_eur", "Primary Pack. Activ.": "primary_pack_activity_eur", 
        "Production Overhead": "production_overhead_eur", "Quality Services": "quality_services_eur", "Environment Protect.": "environment_protect_eur", 
        "Energy Services": "energy_services_eur", "Other Services": "other_services_eur", "(Cross comp. profit)": "cross_comp_profit_eur", 
        "Manufacturing Costs Undiff.": "manufacturing_costs_undiff_eur", "DPC: Delta PUP vs.Standard price": "dpc_delta_vs_stndrd_price_eur",
        "Variances Reposting/Relocation": "variances_reposting_relocation_eur", "Miscellaneous Variances": "miscellaneous_variances_eur",
        "Additional Consolidated Production Costs": "additional_consolidated_prod_cost_eur", "Outbound": "outbound",
        "Inbound": "inbound"})
    
    num_cols = ["gross_sales_qty_kg", "consolidated_marginal_income_eur", "gross_sales_eur", "sales_deductions_eur", 
        "net_sales_eur", "commission_expenses_eur", "license_fees_eur", "outward_freights_eur", "transport_insurance_eur", "other_sales_eur", 
        "total_raw_material_goods_resale_eur", "total_manufact_costs_var_eur", 
        "thereof_replaced_by_cosmos_eur", "set_up_clean_up_eur", 
        "machine_activity_eur", "personnel_activity_eur", "primary_pack_activity_eur", 
        "production_overhead_eur", "quality_services_eur", "environment_protect_eur", 
        "energy_services_eur", "other_services_eur", "cross_comp_profit_eur", 
        "manufacturing_costs_undiff_eur", "dpc_delta_vs_stndrd_price_eur",
        "variances_reposting_relocation_eur", "miscellaneous_variances_eur",
        "additional_consolidated_prod_cost_eur", "outbound", "inbound"]
    
    df['marketing_level_2'] = df['marketing_level_2'].astype(str)

        
    print("5")        
    [df[col].fillna("", inplace=True) for col in df.columns if (df[col].dtype == object)]
    [df.drop(columns=[col], inplace=True) for col in df.columns if ("Unnamed" in col)]
    print(df.columns)
    
    if flag == 0:
        flag = 1
        bwDf = spark.createDataFrame(df)
        bwDf = bwDf.fillna(0.0, subset=['gross_sales_qty_kg'])
        bwDf = bwDf.withColumn('sold_to_party', col('sold_to_party').cast(StringType()))
        bwDf = bwDf.withColumn('gross_sales_qty_kg', col('gross_sales_qty_kg').cast(DoubleType()))
        #bwDf = bwDf.filter(bwDf.gross_sales_qty_kg > 0.0)
        bwDf = bwDf.filter(~(isnan(bwDf.gross_sales_qty_kg)))
        bwDf = bwDf.filter(bwDf.gross_sales_qty_kg.isNotNull())
        bwDf = bwDf.filter(bwDf.sold_to_party != "#")
        bwDf = bwDf.filter(bwDf.prod_hier_2.startswith('75'))
        bwDf = bwDf.filter(bwDf.sales_org.isin(sales_org))
    else:
        tempDf = spark.createDataFrame(df)
        tempDf = tempDf.fillna(0.0, subset=['gross_sales_qty_kg'])
        tempDf = tempDf.withColumn('sold_to_party', col('sold_to_party').cast(StringType()))
        tempDf = tempDf.withColumn('gross_sales_qty_kg', col('gross_sales_qty_kg').cast(DoubleType()))
        #tempDf = tempDf.filter(tempDf.gross_sales_qty_kg > 0.0)
        tempDf = tempDf.filter(~(isnan(tempDf.gross_sales_qty_kg)))
        tempDf = tempDf.filter(tempDf.gross_sales_qty_kg.isNotNull())
        tempDf = tempDf.filter(tempDf.sold_to_party != '#')
        tempDf = tempDf.filter(tempDf.prod_hier_2.startswith('75'))
        tempDf = tempDf.filter(tempDf.sales_org.isin(sales_org))
        
        bwDf = bwDf.union(tempDf)

        temp_df = DynamicFrame.fromDF(tempDf, glueContext, output_dir)
        in_mapping_output_monthly = glueContext.write_dynamic_frame.from_options(frame = temp_df, connection_type = "s3", connection_options = {"path": "s3://cap-qa-data-lake/pricing-app/Input_Source_data/Transaction_data/transaction_data_parquet_files/"+output_dir + "_current_month"}, format = "parquet", transformation_ctx = "in_mapping_output_current_month")
   

bwDf = bwDf.drop_duplicates()

bwDf.filter(bwDf.sold_to_party == '11350598').show()

bw_df = DynamicFrame.fromDF(bwDf, glueContext, output_dir)
in_mapping_output = glueContext.write_dynamic_frame.from_options(frame = bw_df, connection_type = "s3", connection_options = {"path": "s3://cap-qa-data-lake/pricing-app/Input_Source_data/Transaction_data/transaction_data_parquet_files/"+output_dir}, format = "parquet", transformation_ctx = "in_mapping_output")

job.commit()
