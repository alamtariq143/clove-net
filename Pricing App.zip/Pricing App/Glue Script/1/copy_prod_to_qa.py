import boto3

src_bucketname = "cap-prod-data-lake"
trg_bucketname = "cap-qa-data-lake"

s3 = boto3.resource('s3')
my_bucket = s3.Bucket(src_bucketname)


tables = ['A701', 'A970', 'A005', 'TVBUR', "TVKGR", 'KONM', 'T151', 'KNA1', 'KONP', 'MARA', 'TCURR', 'KNVV', 'A006', 'A920', 'T171', 'TCURX','MARC', 'T005T', 'TCURF', 'MVKE', 'ADRC', 'MBEW', 'KNMT', 'T179', 'MARM', 'COV_MD_SEGMENT', 'T006']

for table in tables:

    source = "sap_p1p_tab/processed/" + table
    target = "pricing-app/raw/SAP/" + table
    
    for obj in my_bucket.objects.filter(Prefix=source):
        
        source_filename = (obj.key).split('/')[-1]
        print(source_filename)
        copy_source = {
            'Bucket': src_bucketname,
            'Key': obj.key
        }
        target_filename = "{}/{}".format(target, source_filename)
        s3.meta.client.copy(copy_source, trg_bucketname, target_filename)
        # Uncomment the line below if you wish the delete the original source file
        # s3.Object(bucketname, obj.key).delete()